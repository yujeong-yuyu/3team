import React, {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  useMemo,
  useCallback,
} from 'react';
import '../css/Detail.css';

import { IoSearch, IoHeartOutline, IoCartOutline } from 'react-icons/io5';
import { HiOutlineUser } from 'react-icons/hi';
import { GiHamburgerMenu } from 'react-icons/gi';
import { IoMdClose } from 'react-icons/io';

// 반복 데이터
import data from '../data/detailData.json';
import { NavLink } from 'react-router-dom';

export default function Detail() {
  // --- refs ---
  const headerRef = useRef(null);
  const navRef = useRef(null);
  const gridRef = useRef(null);
  const rightRef = useRef(null);
  const buybarRef = useRef(null);

  // 섹션 스크롤 타깃
  const imgRef = useRef(null);
  const parcelRef = useRef(null);
  const refundRef = useRef(null);
  const sellerRef = useRef(null);
  const reviewRef = useRef(null);

  // 리뷰 모달
  const rvModalRef = useRef(null);

  // --- state ---
  const [navOpen, setNavOpen] = useState(false);
  const [optOpen, setOptOpen] = useState(false); // 구매바 옵션 토글
  const [reviewModal, setReviewModal] = useState({
    open: false, name: '', stars: '', score: '', text: '', thumb: ''
  });

  // 사이드 내비 열릴 때 스크롤 잠금
  useEffect(() => {
    document.body.style.overflow = navOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [navOpen]);
  
  const img = useCallback(
  (p) =>
    process.env.NODE_ENV === "production"
      ? `https://00anuyh.github.io/SouvenirImg${p}`  // 배포용: 깃헙 Pages repo
      : `${process.env.PUBLIC_URL}${p}`,             // 개발용: public 폴더
  []
);

  // 갤러리 소스 (data.json)
  const gallery = useMemo(() => (data.gallery || []).map(img), [img]);

  // 탭 스크롤
  const targets = useMemo(
    () => [imgRef, parcelRef, refundRef, sellerRef, reviewRef],
    []
  );
  const scrollToTarget = (idx) => {
    const headerH = headerRef.current?.offsetHeight || 0;
    const t = targets[idx]?.current; if (!t) return;
    const top = t.getBoundingClientRect().top + window.pageYOffset - headerH - 10;
    window.scrollTo({ top, behavior: 'smooth' });
  };

  // 리뷰 모달 열기
  const openReviewModal = (itemEl) => {
    if (!itemEl) return;
    const name = itemEl.querySelector('.rv-name')?.textContent?.trim() || '';
    const stars = itemEl.querySelector('.rv-stars-static')?.textContent?.trim() || '';
    const score = itemEl.querySelector('.rv-score')?.textContent?.trim() || '';
    const thumb = itemEl.querySelector('.rv-thumb')?.getAttribute('src') || '';
    const copy = itemEl.querySelector('.rv-excerpt')?.cloneNode(true);
    copy?.querySelector('.rv-more')?.remove();
    const text = copy?.textContent?.trim() || '';
    setReviewModal({ open: true, name, stars, score, text, thumb });
  };

  /* ----------------- 구매바 높이/푸터 겹침 보정 ----------------- */
  const recalcBuybar = useCallback(() => {
    const buy = buybarRef.current;
    if (!buy) return;

    // 1) buybar 높이를 CSS 변수로 (페이지 하단 패딩에 사용)
    const h = buy.offsetHeight || 64;
    document.documentElement.style.setProperty('--buybar-h', `${h}px`);

    // 2) 푸터와 겹치면 위로 올리기
    const footer = document.querySelector('footer');
    if (footer) {
      const st = window.pageYOffset || document.documentElement.scrollTop || 0;
      const vh = window.innerHeight || 0;
      const ft = footer.getBoundingClientRect().top + window.pageYOffset;
      const overlap = Math.max(0, st + vh - ft);
      buy.style.transform = `translate3d(0, ${-overlap}px, 0)`;
    } else {
      buy.style.transform = 'translate3d(0,0,0)';
    }
  }, []);

  useEffect(() => {
    recalcBuybar();
    const onScrollResize = () => requestAnimationFrame(recalcBuybar);
    window.addEventListener('scroll', onScrollResize);
    window.addEventListener('resize', onScrollResize);
    return () => {
      window.removeEventListener('scroll', onScrollResize);
      window.removeEventListener('resize', onScrollResize);
    };
  }, [recalcBuybar]);

  // ✅ 옵션 패널 토글 시 즉시 높이 재계산
  useLayoutEffect(() => {
    const r1 = requestAnimationFrame(recalcBuybar);
    const r2 = requestAnimationFrame(recalcBuybar);
    return () => { cancelAnimationFrame(r1); cancelAnimationFrame(r2); };
  }, [optOpen, recalcBuybar]);

  // ✅ 구매바 사이즈 변화 자동 감지
  useEffect(() => {
    if (!buybarRef.current) return;
    const ro = new ResizeObserver(() => recalcBuybar());
    ro.observe(buybarRef.current);
    return () => ro.disconnect();
  }, [recalcBuybar]);

  // ESC로 닫기
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setNavOpen(false);
        setReviewModal(prev => ({ ...prev, open: false }));
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  /* ----- 오른쪽 텍스트: 판매자정보 끝에서 '멈춤' 보정 ----- */
  const clampAside = useCallback(() => {
    const aside  = rightRef.current;
    const seller = sellerRef.current;
    if (!aside || !seller) return;

    const topStr = window.getComputedStyle(aside).top; // e.g. "25%" or "150px"
    let topOffset = parseFloat(topStr) || 0;
    if (/%$/.test(topStr)) {
      topOffset = (parseFloat(topStr) / 100) * window.innerHeight;
    }

    const asideH = aside.offsetHeight || 0;
    const sellerBottom = seller.getBoundingClientRect().bottom + window.pageYOffset;

    const st = window.pageYOffset || 0;
    const desiredTop = st + topOffset;
    const overflow = Math.max(0, (desiredTop + asideH) - sellerBottom);

    aside.style.transform = `translateY(${-overflow}px)`;
  }, []);

  useEffect(() => {
    clampAside();
    const onScrollResize = () => requestAnimationFrame(clampAside);
    window.addEventListener('scroll', onScrollResize);
    window.addEventListener('resize', onScrollResize);

    const imgs = Array.from(document.querySelectorAll('.detail-left img'));
    const onImgLoad = () => clampAside();
    imgs.forEach(imgEl => {
      if (imgEl.complete) return;
      imgEl.addEventListener('load', onImgLoad, { once: true });
    });

    return () => {
      window.removeEventListener('scroll', onScrollResize);
      window.removeEventListener('resize', onScrollResize);
      imgs.forEach(imgEl => imgEl.removeEventListener?.('load', onImgLoad));
    };
  }, [clampAside]);

  return (
    <div className="detail-warp1">
      <header id="detail-header" ref={headerRef}>
        <div id="header-left">
          <button
            id="hamburger"
            type="button"
            aria-expanded={navOpen}
            aria-label={navOpen ? '메뉴 닫기' : '메뉴 열기'}
            onClick={() => setNavOpen(v => !v)}
          >
            {navOpen ? <IoMdClose size={22} /> : <GiHamburgerMenu size={22} />}
          </button>

          <div id="detail-tap" className="detail-tabs">
            {(data.tabs || ['상품이미지','배송안내','교환/환불안내','판매자정보','리뷰']).map((t, idx) => (
              <button type="button" key={t} onClick={() => scrollToTarget(idx)}>{t}</button>
            ))}
          </div>
        </div>
        <NavLink to="/" className={({ isActive }) => isActive ? "active" : undefined} >
          <img src="/img/logo.png" alt="logo" />
        </NavLink>
        <div id="header-right">
          <a href="#none" aria-label="검색"><IoSearch size={22} /></a>
          <a href="#none" aria-label="계정"><HiOutlineUser size={22} /></a>
          <a href="#none" aria-label="찜"><IoHeartOutline size={22} /></a>
          <a href="#none" aria-label="장바구니"><IoCartOutline size={22} /></a>
        </div>
      </header>

      {/* SIDE NAV */}
      <nav id="detail-nav" className={navOpen ? 'open' : ''} ref={navRef}>
        <ul id="detail-menu1">
          <li className="hamprofile">
            <p><span>임재형</span> 님</p>
            <p>Lv.2<span> 루키</span></p>
            <p>사용 가능 쿠폰 : <span>3장</span></p>
          </li>
          <li><NavLink to="/lifestyle" className={({ isActive }) => isActive ? "active" : undefined}>
            LIFESTYLE
          </NavLink></li>
          <li><NavLink to="/lighting" className={({ isActive }) => isActive ? "active" : undefined}>
            LIGHTING
          </NavLink></li>
          <li><NavLink to="/Objects" className={({ isActive }) => isActive ? "active" : undefined}>
            OBJECTS
          </NavLink></li>
          <li><NavLink to="/Community" className={({ isActive }) => isActive ? "active" : undefined}>
            COMMUNITY
          </NavLink></li>
        </ul>
      </nav>

      {/* MAIN */}
      <main id="detailPage">
        <div className="detail-grid" ref={gridRef}>
          {/* 왼쪽 */}
          <section className="detail-left">
            {/* 이미지 */}
            <div className="detail-img" ref={imgRef}>
              {gallery.map((src, i) => (
                <img key={i} src={src} alt={`detail-${i + 1}`} />
              ))}
            </div>

            {/* 배송 */}
            <div className="detail-inpo detail-parcel" ref={parcelRef}>
              <h3 className="detail-info-title">배송</h3>
              <table className="detail-info-table"><tbody>
                {(data.shipping || []).map(([th, td]) => (
                  <tr key={th}><th>{th}</th><td>{td}</td></tr>
                ))}
              </tbody></table>
            </div>

            {/* 교환/환불 */}
            <div className="detail-inpo detail-refund" ref={refundRef}>
              <h3 className="detail-info-title">교환/환불</h3>
              <table className="detail-info-table"><tbody>
                {(data.refund || []).map(([th, td]) => (
                  <tr key={th}><th>{th}</th><td>{td}</td></tr>
                ))}
              </tbody></table>

              <h4 className="detail-info-subtitle">반품/교환 사유에 따른 요청 가능 기간</h4>
              <ol className="detail-info-list">
                {(data.refundGuides?.period || []).map((li, idx) => <li key={idx}>{li}</li>)}
              </ol>

              <h4 className="detail-info-subtitle">반품/교환 불가 사유</h4>
              <ol className="detail-info-list">
                {(data.refundGuides?.notAllowed || []).map((li, idx) => <li key={idx}>{li}</li>)}
              </ol>
            </div>

            {/* 판매자 */}
            <div className="detail-inpo seller" ref={sellerRef}>
              <h3 className="detail-info-title">판매자 정보</h3>
              <table className="detail-info-table"><tbody>
                {(data.seller || []).map(([th, td]) => (
                  <tr key={th}><th>{th}</th><td>{td}</td></tr>
                ))}
              </tbody></table>
            </div>

            {/* 리뷰 */}
            <div className="detail-inpo detail-review" id="review" ref={reviewRef}>
              <h3 className="detail-info-title">리뷰</h3>

              <form className="rv-form" onSubmit={(e)=>e.preventDefault()}>
                <div className="rv-top">
                  <div className="rv-avatar lg" aria-hidden="true" />
                  <div className="rv-meta">
                    <p className="rv-nick"><b>임재형 님</b></p>
                    <div className="rv-stars" data-score="0" aria-label="별점 선택">
                      {[1,2,3,4,5].map(v => (
                        <button type="button" key={v} className="star" aria-label={`${v}점`}>☆</button>
                      ))}
                    </div>
                  </div>
                  <label className="rv-photo-btn">
                    <input type="file" accept="image/*" hidden />
                    <span>사진첨부하기</span>
                  </label>
                </div>
                <textarea className="rv-text" placeholder="솔직한 후기를 작성해주세요. (최소 10자)" />
                <button className="rv-submit" type="submit">등록하기</button>
              </form>

              <div className="rv-filter">
                <button className="detail-on" type="button">최신순</button>
                <button type="button">평점 높은순</button>
                <button type="button">평점 낮은순</button>
                <button type="button">사진 리뷰만 보기</button>
              </div>

              <ul className="rv-list">
                {(data.reviews || []).map((rv, idx) => (
                  <li className="rv-item" key={idx}>
                    <div className="rv-head">
                      <div className="rv-avatar" aria-hidden="true" />
                      <div>
                        <p className="rv-name">{rv.name}</p>
                        <p className="rv-starline">
                          <span className="rv-stars-static">{rv.stars}</span>
                          <span className="rv-score">{rv.score}</span>
                        </p>
                      </div>
                    </div>
                    <div className="rv-body">
                      <img
                        className="rv-thumb"
                        src={img(rv.thumb)}
                        alt="리뷰 사진"
                        onClick={(e)=>openReviewModal(e.currentTarget.closest('.rv-item'))}
                      />
                      <p className="rv-excerpt">
                        {rv.excerpt}
                        <a
                          href="#none"
                          className="rv-more"
                          onClick={(e)=>{e.preventDefault(); openReviewModal(e.currentTarget.closest('.rv-item'));}}
                        >
                          [더보기]
                        </a>
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </section>

          {/* 오른쪽 상세설명 (판매자정보 끝에서 멈춤) */}
          <aside className="detail-right" ref={rightRef}>
            <div className="detail-text">
              <div className="detail-brand">{data.product.brand}</div>
              <h1 className="detail-name">{data.product.name}</h1>
              <div className="detail-price">{data.product.price}</div>
              <p className="detail-desc">
                트로이 목마를 연상시키는 우드 장식입니다.<br />
                부드러운 곡선과 투박한 마감이 어우러져 빈티지한 매력을 더합니다.<br />
                레이스 장식이 포인트로, 아이방이나 햇살 가득한 선반에 두면<br />
                공간에 따뜻한 감성을 더해줍니다.
              </p>
              <h4 className="detail-subhead">Details</h4>
              <ul className="detail-list">
                {(data.product.details || []).map(d => (
                  <li key={d.label}><strong>{d.label}</strong>: {d.value}</li>
                ))}
              </ul>
            </div>
          </aside>
        </div>

        {/* 구매바 */}
        <div id="detail-buybar" className="detail-buybar" ref={buybarRef}>
          <div className="detail-buybar-box">
            <div className="db-left">
              <p className="detail-buybar-title">{data.product.name}</p>
              <p className="detail-buybar-price">{data.product.price}</p>
              <div className="detail-option" style={{ display: optOpen ? 'block' : 'none' }}>
                <div className="detail-label-box">
                  <label className="detail-label">옵션</label>
                  <select id="detail-opt" defaultValue="기본 구성">
                    <option>기본 구성</option>
                    <option>레이스 리본 포함(+₩3,000)</option>
                  </select>
                </div>
                <div className="detail-actions">
                  <button className="detail-cartBtn" type="button">CART</button>
                  <button className="detail-buyBtn" type="button">BUY</button>
                </div>
              </div>
            </div>

            <div className="detail-buybar-right">
              <button
                className="detail-buybar-actions"
                type="button"
                aria-expanded={optOpen}
                onClick={() => {
                  setOptOpen(v => !v);
                  requestAnimationFrame(recalcBuybar);
                }}
              >
                <span className="caret">{optOpen ? 'OPTION ▲' : 'OPTION ▼'}</span>
              </button>

              <div className="detail-option" style={{ display: optOpen ? 'block' : 'none' }}>
                <div className="detail-qty">
                  <button className="qty-btn" type="button">-</button>
                  <input className="qty-input" type="text" defaultValue="1" />
                  <button className="qty-btn" type="button">+</button>
                </div>
                <p className="detail-total">총합 {data.product.price}</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 리뷰 모달 */}
      <aside
        id="rv-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="rvm-title"
        ref={rvModalRef}
        style={{ display: reviewModal.open ? 'block' : 'none' }}
      >
        <button
          type="button"
          className="rvm-close"
          aria-label="닫기"
          onClick={() => setReviewModal(p => ({ ...p, open: false }))}
        >
          ×
        </button>
        <div className="rvm-hero-wrap">
          {reviewModal.thumb ? <img className="rvm-hero" src={reviewModal.thumb} alt="리뷰 이미지" /> : null}
        </div>
        <div className="rvm-head">
          <div className="rvm-avatar" aria-hidden="true" />
          <div className="rvm-meta">
            <h4 id="rvm-title" className="rvm-name">{reviewModal.name}</h4>
            <p className="rvm-starline"><span className="rvm-stars">{reviewModal.stars} {reviewModal.score}</span></p>
          </div>
        </div>
        <div className="rvm-body">
          <p className="rvm-text">{reviewModal.text}</p>
        </div>
      </aside>

      {/* 네비 백드롭 */}
      {navOpen && <div className="nav-backdrop" aria-hidden="true" onClick={() => setNavOpen(false)} />}
    </div>
  );
}
