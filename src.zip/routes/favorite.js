import "../css/favorite.css";

// 장바구니 상품 데이터 (예시)
const items = [
    { id: 1, name: "상품명 A", price: 15000, img: "/img/sec1img3.png" },
    { id: 2, name: "상품명 B", price: 20000, img: "/img/sec1img3.png" },
    { id: 3, name: "상품명 C", price: 30000, img: "/img/sec1img3.png" },
    { id: 4, name: "상품명 D", price: 40000, img: "/img/sec1img3.png" },
    { id: 5, name: "상품명 E", price: 50000, img: "/img/sec1img3.png" },
    { id: 6, name: "상품명 F", price: 60000, img: "/img/sec1img3.png" },
    { id: 7, name: "상품명 G", price: 70000, img: "/img/sec1img3.png" },
];

function chunkArray(array, size) {
    const result = [];
    for (let i = 0; i < array.length; i += size) {
        result.push(array.slice(i, i + size));
    }
    return result;
}

const Favorite = () => {
    // 3개씩 끊어서 fav-row 배열 생성
    const rows = chunkArray(items, 3);

    return (
        <div id="fav-wrap">
            <div className="fav-title">favorite</div>
            <div className="fav-line"></div>

            <div className="fav-container">
                {rows.map((row, rowIndex) => (
                    <div className="fav-row" key={rowIndex}>
                        {row.map((it) => (
                            <div className="fav-box" key={it.id}>
                                <img src={it.img} alt={it.name} />
                                <p>
                                    {it.name}
                                    <br />
                                    ￦ {it.price.toLocaleString()}
                                </p>
                                <i className="fa-solid fa-heart"></i>
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Favorite;
