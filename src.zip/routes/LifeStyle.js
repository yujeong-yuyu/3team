import "../css/LifeStyle.css"

import React, { useEffect, useRef, useState, useMemo } from "react";
import { IoIosArrowDown } from "react-icons/io";

export default function LifeStyle() {
  const heroRef = useRef(null);
  const [active, setActive] = useState(0);

  const base = process.env.PUBLIC_URL || "";
  const images = Array.from({ length: 4 }, (_, i) => `https://00anuyh.github.io/SouvenirImg/D_ban1img${i + 1}.png`);

  const heroMap = [0, 1, 2, 3];
  const triggersConf = Array.from({ length: 4 }, (_, i) => {
    const num = Math.floor(i / 2) + 1;
    const cls = i % 2 === 0 ? `decor decor-${num}` : `square square-${num}`;
    return {
      cls,
      src: `https://00anuyh.github.io/SouvenirImg/D_ban2img${i + 1}.png`,
      hero: heroMap[i],
    };
  });

  useEffect(() => {
    const scope = heroRef.current;
    if (!scope) return;

    let order = Array.from(scope.querySelectorAll(".decor, .square"));

    const BASE_RIGHT = 800;
    const CC_GAP = 60;

    const applyPositions = () => {
      const widths = order.map((el) => el.getBoundingClientRect().width);
      let r = BASE_RIGHT; // 왼쪽 시작 기준

      order.forEach((el, i) => {
        if (i !== 0) {
          // 이전 요소 반폭 + 현재 요소 반폭 + 간격
          r += (widths[i - 1] / 2) + (widths[i] / 2) + CC_GAP;
        }
        el.style.position = "absolute";
        el.style.top = "50%";
        el.style.left = `${r}px`;   // ✅ right → left 로 변경
      });
    };

    applyPositions();

    const onClick = (e) => {
      const btn = e.target.closest(".decor, .square");
      if (!btn || !scope.contains(btn)) return;
      e.preventDefault();

      // 메인 이미지 전환
      const to = Number(btn.dataset.hero);
      setActive(
        Number.isNaN(to)
          ? (prev) => (prev + 1) % images.length
          : ((to % images.length) + images.length) % images.length
      );

      // 현재 순서로 동기화
      order = Array.from(scope.querySelectorAll(".decor, .square"))
        .sort((a, b) => Number(a.dataset.order ?? 0) - Number(b.dataset.order ?? 0));

      const idx = order.indexOf(btn);
      if (idx === -1) return;

      // 클릭 요소 맨 앞 + 이후 → 이전 순서
      order = order.slice(idx).concat(order.slice(0, idx));
      applyPositions();
    };

    const onResize = () => {
      order = Array.from(scope.querySelectorAll(".decor, .square"))
        .sort((a, b) => Number(a.dataset.order ?? 0) - Number(b.dataset.order ?? 0));
      applyPositions();
    };

    scope.addEventListener("click", onClick);
    window.addEventListener("resize", onResize);
    return () => {
      scope.removeEventListener("click", onClick);
      window.removeEventListener("resize", onResize);
    };
  }, [images.length]);

  return (
    <>
      <section className="hero" ref={heroRef}>
        <div className="container hero-grid">
          <figure className="hero-main">
            {images.map((src, i) => (
              <img
                key={src}
                src={src}
                alt={`hero ${i + 1}`}
                className={i === active ? "is-active" : ""}
              />
            ))}
          </figure>

          {triggersConf.map((t, i) => (
            <div key={i} className={t.cls} data-hero={t.hero}>
              <img src={t.src} alt="" />
            </div>
          ))}
        </div>
      </section>
      <ProductList />
    </>
  );
}

function ProductList() {
  const items = useMemo(
    () =>
      Array.from({ length: 60 }, (_, i) => ({
        id: i + 1,
        name: "제품명",
        price: "₩00,000",
        src: `https://00anuyh.github.io/SouvenirImg/D_sec1img${(i % 9) + 1}.png`,
        soldout: i === 3 || i === 8 || i === 18 || i === 36,
      })),
    []
  );

  const STEP = 8;
  const [showing, setShowing] = useState(STEP);
  const [likes, setLikes] = useState(() => new Set());

  const toggleLike = (id) =>
    setLikes((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const HEART = (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M12.1 21s-6.4-4.2-9-6.8A5.8 5.8 0 0 1 12 6a5.8 5.8 0 0 1 8.9 8.3c-2.6 2.7-8.8 6.7-8.8 6.7z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
  const BAG = (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M6 8h12l-1.2 12H7.2L6 8z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
      />
      <path
        d="M9 8V6a3 3 0 0 1 6 0v2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );

  const visible = items.slice(0, showing);

  return (
    <section className="section">
      <div className="container">
        <h2 className="section-title">LIFESTYLE</h2>
        <div className="section-line"></div>

        <ul className="product-grid">
          {visible.map((p) => (
            <li className="product-card" key={p.id}>
              <a className="product-media" href="#!">
                <img src={p.src} alt="sec1img" />
                {p.soldout && <span className="badge soldout" aria-hidden="true" />}
                <span className="meta name">{p.name}</span>
                <span className="meta price">{p.price}</span>
              </a>

              {/* 찜 */}
              <button
                className="icon-btn like"
                type="button"
                aria-pressed={likes.has(p.id) ? "true" : "false"}
                aria-label="찜하기"
                title="찜하기"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  toggleLike(p.id);
                }}
              >
                {HEART}
              </button>

              {/* 장바구니 */}
              <button
                className="icon-btn cart"
                type="button"
                aria-label="장바구니 담기"
                title="장바구니 담기"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  console.log("장바구니 담기!", p.id);
                }}
              >
                {BAG}
              </button>
            </li>
          ))}
        </ul>

        <div className="more">
          {showing < items.length && (
            <button
              className="btn-more"
              type="button"
              onClick={() =>
                setShowing((s) => Math.min(s + STEP, items.length))
              }
            >
              more <IoIosArrowDown className="IoIosArrowDown" />
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
